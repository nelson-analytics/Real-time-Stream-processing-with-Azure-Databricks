namespace Taxi
{
    public enum DataFormat
    {
        Csv,
        Json
    }
}